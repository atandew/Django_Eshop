from store.models import Category, Product
from django.shortcuts import render, redirect
from django.views import View


class Index(View):

    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if (quantity == 1):
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1

                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print('cart=>', request.session['cart'])

        return redirect('homepage')

    def get(self, request):
        if not request.session.get('cart'):
            request.session['cart'] = {}
        _products = None
        # request.session.clear()
        _categories = Category.get_all_categories();

        categoryID = request.GET.get('category')
        if categoryID:
            _products = Product.get_products_by_Category_Id(categoryID)
        else:
            _products = Product.get_all_products();

        print(request.GET)
        data = {}
        data['products'] = _products
        data['categories'] = _categories
        print('you are', request.session.get('customer_email'), 'with id=', request.session.get('customer_id'))
        return render(request, 'index.html', data)
