from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password, make_password
from store.models.customer import Customer
from django.views import View


class SignUp(View):

    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        firstName = postData.get('firstname')
        lastName = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')

        value = {
            'first_name': firstName,
            'last_name': lastName,
            'phone': phone,
            'email': email,
            'password': password
        }
        customer = Customer(first_name=firstName, last_name=lastName, phone=phone, email=email, password=password)
        # validation
        validationResult = self.validate_customer(firstName, lastName, phone, email, password, customer)
        error = validationResult['error']
        error_message = validationResult['error_message']
        print(firstName, lastName, phone, email, password)
        if not error:
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error_message': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validate_customer(self,firstName, lastName, phone, email, password, customer):
        error = False;
        error_message = {}
        error_message['firstName'] = "noError"
        error_message['lastName'] = "noError"
        error_message['email'] = "noError"
        error_message['phone'] = "noError"
        error_message['password'] = 'noError'
        if not firstName:
            error = True
            error_message['firstName'] = "First Name required"

        elif len(firstName) < 4:
            error = True
            error_message['firstName'] = "First Name must be greater than 4 character"

        if not lastName:
            error = True
            error_message['lastName'] = "Last Name Required"

        elif len(lastName) < 4:
            error = True
            error_message['lastName'] = "Last Name must be greater than 4 character"

        if not phone:
            error = True
            error_message['phone'] = "Phone No. Required"

        elif len(phone) != 10:
            error = True
            error_message['phone'] = "Phone no should be of 10 numbers only"

        if not email:
            error = True
            error_message['email'] = "Email Required"

        elif len(email) < 6:
            error = True
            error_message['phone'] = "Please enter a valid email"

        if not password:
            error = True
            error_message['password'] = "Password is required"

        elif len(password) < 6:
            error = True
            error_message['password'] = "Password must be of 6 characters at least"

            # check if users email already registered
        if customer.isEmailExists():
            error = True
            error_message['email'] = "Email already exists"

        validationRes = {
            'error': error,
            'error_message': error_message
        }

        return validationRes
